/**
 * Placeholder for artwork you will drop in later.
 * Replace the whole component call with <Image src="/your-file.jpg" ... /> —
 * the label tells you what each slot expects.
 */
export default function ImageSlot({ label, ratio = "aspect-[4/3]", className = "" }) {
  return (
    <div
      className={`${ratio} ${className} flex items-center justify-center border-2 border-dashed border-ink bg-wash`}
      role="img"
      aria-label={`Image placeholder: ${label}`}
    >
      <span className="px-4 text-center text-sm font-semibold text-neutral-700">{label}</span>
    </div>
  );
}
