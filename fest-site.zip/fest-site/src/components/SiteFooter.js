export default function SiteFooter() {
  return (
    <footer className="mt-20 border-t-2 border-ink">
      <div className="mx-auto flex max-w-6xl flex-col gap-2 px-5 py-8 text-sm text-neutral-600 sm:flex-row sm:items-center sm:justify-between">
        <p>Fest 2026 — organised by the student council.</p>
        <p>
          Trouble registering? Write to{" "}
          <a className="font-semibold text-ink underline" href="mailto:fest@sode-edu.in">
            fest@sode-edu.in
          </a>
        </p>
      </div>
    </footer>
  );
}
