import Link from "next/link";
import ImageSlot from "@/components/ImageSlot";
import { COMPETITIONS, THEMES } from "@/lib/competitions";
import { getSettings } from "@/lib/server";
import { formatDate, isPast, daysLeft } from "@/lib/dates";

export const dynamic = "force-dynamic";

function Countdown({ deadline }) {
  if (isPast(deadline)) {
    return <span className="border-2 border-ink px-2 py-1 text-xs font-bold">Closed</span>;
  }
  const left = daysLeft(deadline);
  if (left === null) return null;
  return (
    <span className="bg-signal px-2 py-1 text-xs font-bold">
      {left <= 0 ? "Closes today" : left === 1 ? "1 day left" : `${left} days left`}
    </span>
  );
}

function CompetitionRow({ comp, deadline }) {
  const closed = isPast(deadline);
  return (
    <article className="grid gap-5 border-b-2 border-ink py-8 md:grid-cols-[13rem_1fr_auto] md:items-center">
      <ImageSlot label={`${comp.name} card image`} ratio="aspect-[16/10]" />

      <div className="min-w-0">
        <p className="text-sm font-semibold text-neutral-600">{comp.kicker}</p>
        <h3 className="font-display text-3xl font-extrabold">{comp.name}</h3>
        <p className="mt-2 max-w-[60ch] text-neutral-700">{comp.summary}</p>
        <p className="mt-3 text-sm font-semibold">{comp.teamSizeLabel}</p>
      </div>

      <div className="flex flex-col items-start gap-3 md:items-end">
        <div className="md:text-right">
          <p className="text-sm text-neutral-600">Registration closes</p>
          <p className="font-display text-xl font-bold">{formatDate(deadline)}</p>
        </div>
        <Countdown deadline={deadline} />
        {closed ? (
          <span className="btn-quiet cursor-not-allowed border-rule text-neutral-400">
            Registration closed
          </span>
        ) : (
          <Link href={`/register/${comp.slug}`} className="btn-primary">
            Register for {comp.name}
          </Link>
        )}
      </div>
    </article>
  );
}

export default async function HomePage() {
  const settings = await getSettings();
  const techcon = settings.techcon || {};

  const schedule = [
    { label: "Registration closes", value: techcon.registrationDeadline },
    { label: "Paper submission", value: techcon.paperDeadline },
    { label: "Final PPT", value: techcon.pptDeadline },
    { label: "Competition day", value: techcon.eventDate },
  ];

  return (
    <>
      {/* Hero */}
      <section className="border-b-2 border-ink">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-[1.15fr_1fr] md:items-center md:py-20">
          <div>
            <p className="inline-block bg-ink px-3 py-1 text-sm font-semibold text-paper">
              26 October 2026
            </p>
            <h1 className="mt-5 font-display text-5xl font-extrabold leading-[0.95] sm:text-7xl">
              Three competitions.
              <br />
              <span className="bg-signal px-2">One sign-in.</span>
            </h1>
            <p className="mt-6 max-w-[52ch] text-lg text-neutral-700">
              Papers, bots and builds. Sign in with your college email, register your team once,
              and every deadline you need lives on this page.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="#competitions" className="btn-primary">
                See the competitions
              </Link>
              <Link href="/login" className="btn-quiet">
                Sign in with college email
              </Link>
            </div>
          </div>

          <ImageSlot label="Hero image — fest poster or last year's photo" ratio="aspect-[4/5]" />
        </div>
      </section>

      {/* Competitions */}
      <section id="competitions" className="mx-auto max-w-6xl scroll-mt-20 px-5 py-14">
        <h2 className="font-display text-4xl font-extrabold">Pick your competition</h2>
        <p className="mt-2 max-w-[60ch] text-neutral-700">
          Only the team leader registers. Teammates are entered on the form and do not need to
          sign in. You can lead a team in more than one competition.
        </p>

        <div className="mt-8 border-t-2 border-ink">
          {Object.values(COMPETITIONS).map((comp) => (
            <CompetitionRow
              key={comp.slug}
              comp={comp}
              deadline={settings[comp.slug]?.registrationDeadline}
            />
          ))}
        </div>
      </section>

      {/* TechCon details */}
      <section id="techcon-details" className="scroll-mt-20 border-y-2 border-ink bg-wash">
        <div className="mx-auto max-w-6xl px-5 py-14">
          <h2 className="font-display text-4xl font-extrabold">TechCon, in detail</h2>
          <p className="mt-2 max-w-[60ch] text-neutral-700">
            Teams of two, one theme, an IEEE-format paper and a six-minute slot on stage.
          </p>

          <div className="mt-10 grid gap-10 lg:grid-cols-[1.1fr_1fr]">
            <div>
              <h3 className="font-display text-2xl font-bold">Themes</h3>
              <p className="mt-1 text-neutral-700">Choose one when you register.</p>
              <ul className="mt-4 grid gap-2 sm:grid-cols-2">
                {THEMES.map((theme) => (
                  <li
                    key={theme}
                    className="border-2 border-ink bg-paper px-3 py-2.5 text-sm font-semibold"
                  >
                    {theme}
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="font-display text-2xl font-bold">Schedule</h3>
              <p className="mt-1 text-neutral-700">
                Dates are kept current here — check back rather than relying on a screenshot.
              </p>
              <ol className="mt-4 border-t-2 border-ink">
                {schedule.map((item, i) => (
                  <li
                    key={item.label}
                    className="flex items-baseline gap-4 border-b-2 border-ink bg-paper px-4 py-3"
                  >
                    <span className="font-display text-sm font-bold text-neutral-500">
                      {i + 1}
                    </span>
                    <span className="flex-1 text-sm font-semibold">{item.label}</span>
                    <span className="font-display text-sm font-bold">
                      {formatDate(item.value)}
                    </span>
                  </li>
                ))}
              </ol>
            </div>
          </div>

          <div className="mt-12 grid gap-8 md:grid-cols-2">
            <div className="border-2 border-ink bg-paper p-6 shadow-hard">
              <h3 className="font-display text-xl font-bold">Paper guidelines</h3>
              <ul className="mt-3 space-y-2 text-sm text-neutral-800">
                <li>Prepare the paper in IEEE format.</li>
                <li>Work must be original and properly referenced.</li>
                <li>A plagiarism check through the college library is mandatory.</li>
                <li>Finish the plagiarism check before you submit the final paper.</li>
              </ul>
            </div>

            <div className="border-2 border-ink bg-paper p-6 shadow-hard">
              <h3 className="font-display text-xl font-bold">Presentation guidelines</h3>
              <ul className="mt-3 space-y-2 text-sm text-neutral-800">
                <li>Six minutes per team: five to present, one for questions.</li>
                <li>Both team members take part in the presentation.</li>
                <li>Submit the final PPT before the deadline above.</li>
              </ul>
            </div>
          </div>

          <div className="mt-10 flex flex-wrap items-center gap-3 border-2 border-ink bg-paper p-5">
            <p className="flex-1 text-sm font-semibold">
              Already registered for TechCon? Upload your paper and PPT links here.
            </p>
            <Link href="/submit/techcon" className="btn-primary">
              Go to submissions
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
